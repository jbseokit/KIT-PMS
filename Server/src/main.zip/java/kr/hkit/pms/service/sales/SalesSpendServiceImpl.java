package kr.hkit.pms.service.sales;

public class SalesSpendServiceImpl implements SalesSpendService {

}
