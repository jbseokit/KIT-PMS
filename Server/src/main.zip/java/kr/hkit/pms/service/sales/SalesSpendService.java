package kr.hkit.pms.service.sales;

public interface SalesSpendService {

}
