package kr.hkit.pms.mapper.sales;

import kr.hkit.pms.domain.sales.SalesSpendDto;

public interface SalesSpendMapper {
	
//	public void insert(SalesSpendDto spend_board);
//	public SalesSpendDto read(Long SPEND_MANA_IDX);
//	public int delete(Long SPEND_MANA_IDX);	
//	public int update(SalesSpendDto spend_board);
	
}
 