package kr.hkit.pms.mapper.board;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {
	// 임시로 생성한 인터페이스
}
